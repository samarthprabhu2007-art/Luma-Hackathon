After the round, recreate the test snapshot and evaluation key in an empty directory. Run from facilitator_only/tools with Python 3.9 or later.

    python generate_book.py --phrases heldout_phrasebook.csv --profile v2 --per-language 840 --seed 511743 --outcome-seed 118259 --out reconstructed_test
