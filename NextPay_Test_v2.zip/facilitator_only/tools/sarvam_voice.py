"""Optional: create a fresh Bulbul WAV for one utterance in the supplied manifest (one API call)."""
import argparse
import base64
import csv
import json
import os
import sys
from pathlib import Path
from urllib.request import Request, urlopen


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', required=True, type=Path)
    parser.add_argument('--utterance-id', required=True)
    parser.add_argument('--out', required=True, type=Path)
    args = parser.parse_args()
    if args.out.exists():
        parser.error('Choose a new WAV filename.')
    key = os.environ.get('SARVAM_API_KEY')
    if not key:
        parser.error('Set SARVAM_API_KEY in your environment first.')
    with args.manifest.open(encoding='utf-8-sig', newline='') as source:
        record = next((r for r in csv.DictReader(source) if r['utterance_id'] == args.utterance_id), None)
    if record is None:
        parser.error('Unknown utterance ID.')
    payload = {'model': 'bulbul:v3', 'text': record['transcript'], 'language_code': record['language_code'],
               'speech_sample_rate': 8000, 'output_audio_codec': 'wav'}
    request = Request('https://api.sarvam.ai/text-to-speech', method='POST',
                      data=json.dumps(payload).encode(), headers={'Content-Type':'application/json','api-subscription-key':key})
    with urlopen(request, timeout=60) as response:
        raw = base64.b64decode(json.load(response)['audios'][0], validate=True)
    if raw[:4] != b'RIFF' or raw[8:12] != b'WAVE':
        sys.exit('No valid WAV received.')
    args.out.parent.mkdir(parents=True, exist_ok=True)
    with args.out.open('xb') as target:
        target.write(raw)
    print(args.out)


if __name__ == '__main__':
    main()
