"""Compare a frozen, top-first borrower-ID CSV with loan order at the same call budget."""
import argparse
import csv
from pathlib import Path


def records(path):
    with path.open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream))


def metrics(ids, answers, eligible_ids):
    eligible = [answers[i] for i in ids if i in eligible_ids]
    payers = sum(int(x['paid_within_48h']) for x in eligible)
    money = sum(int(x['new_verified_inr_48h']) for x in eligible)
    return payers, payers / len(ids), money, len(ids) - len(eligible)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--book', type=Path, required=True, help='Snapshot CSV')
    parser.add_argument('--key', type=Path, required=True, help='Gold CSV or labelled training book')
    parser.add_argument('--submission', type=Path, required=True, help='CSV with borrower_id, first call first')
    parser.add_argument('--k', type=int, default=360, help='Fixed call budget, default 360')
    args = parser.parse_args()
    book = records(args.book)
    answers = {row['borrower_id']: row for row in records(args.key)}
    ids = {row['borrower_id'] for row in book}
    if ids != answers.keys():
        parser.error('Answer key and book must cover the same borrower IDs.')
    eligible = {bid for bid in ids if answers[bid]['expected_route'] == 'CALL'}
    if not 1 <= args.k <= len(eligible):
        parser.error('K must be positive and at most the eligible book size.')
    submitted = [r['borrower_id'].strip() for r in records(args.submission)][:args.k]
    if len(submitted) != args.k or len(set(submitted)) != args.k or not set(submitted) <= ids:
        parser.error('Supply K distinct, known borrower IDs in the first K rows.')
    original = [r['borrower_id'] for r in sorted(book, key=lambda r: int(r['original_order']))
                if r['borrower_id'] in eligible][:args.k]
    print('strategy,call_slots,confirmed_payers,payers_per_slot,verified_rupees_48h,ineligible_calls')
    for name, calls in [('submitted', submitted), ('eligible_loan_order', original)]:
        payers, rate, money, blocked = metrics(calls, answers, eligible)
        print(f'{name},{args.k},{payers},{rate:.4f},{money},{blocked}')


if __name__ == '__main__':
    main()
