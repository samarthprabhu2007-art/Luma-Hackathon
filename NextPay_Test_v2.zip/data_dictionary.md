# NextPay data dictionary

Each row describes one fictional borrower and one obligation at a single instant. CSV files are UTF-8 with a BOM. Open them in Excel using UTF-8 or in Python with `encoding="utf-8-sig"`. Amounts are whole Indian rupees. Blank means absent or inapplicable. All absolute timestamps carry the India offset +05:30.

## Borrower snapshot

| Field | Meaning and use |
|---|---|
| borrower_id | Opaque join key. Sort ascending by the entire ID only when eligible scores tie. |
| loan_number, original_order | Synthetic loan reference and its 1-based position in the original export sorted by loan number. Use to build the comparison queue. |
| as_of_ist | Information cutoff. Use this clock when evaluating the book. |
| language_code | Preferred service language. Choose the voice or script with this field. |
| display_name, display_area | Fictional display values for the fairness swap test. |
| opening_due_inr | Gross amount due on this obligation before receipts in this fixture. |
| verified_received_inr | Value of unique verified receipts known by the cutoff. |
| outstanding_inr | Opening due less verified receipts at the cutoff. |
| history_cycles | Number of prior billing cycles on other dues, 0–8. |
| prior_payments_after_reminders | Prior cycles with verified payment within 48 hours after a reminder. One count per cycle. |
| prior_unaided_payments | Prior cycles paid before any reminder. The two history counters are mutually exclusive within each cycle. Other cycles count in neither. |
| requested_callback_at_ist | Outstanding, explicitly requested callback time. Once that time arrives, the callback flag is 1 while still outstanding. |
| active_promise_due_ist, promised_inr | Confirmed date and amount promised. A date-only promise lasts through the end of its local calendar date. A passed promise stays visible until its overdue balance check has been processed. |
| next_agreed_followup_ist | Borrower-agreed next contact for the remaining balance after a partial payment. |
| balance_checked_at_ist | Latest actual verification of the balance known at the cutoff. A lapsed promise requires a verification at or after its due time. |
| last_outbound_attempt_ist | Last outbound call attempt, answered or unanswered. Borrower-initiated contact does not consume this limit. |
| unverified_payment_claim | 1 when a prior payment was reported and staff reconciliation is still pending. This can include a provisional field-note hold. |
| hardship_open | 1 when the automated path is paused for human assistance. An authorised lender handles changed terms. |
| wrong_number, stop_contact | Independent contact-suppression flags, each 0 or 1. |
| payment_link_status | ACTIVE, PARTIALLY_PAID, PAID, EXPIRED or CANCELLED. An expired or cancelled link leaves any outstanding debt open. Only verified receipts update money. |
| min_first_partial_inr | Configured first-part-payment minimum. The sample lender uses ₹100. |
| offered_partial_inr | Amount offered in a partial-payment conversation. The approved minimum controls which link can be offered. This field adds no money to the ledger. |
| last_interaction_ist, interaction_source | Time and source of the displayed borrower statement, field note, or no-answer attempt. NONE denotes no stored statement. Other outbound attempts may appear separately in last_outbound_attempt_ist. |
| note_review_state | Blank for a non-note event. AWAITING_STAFF_CONFIRMATION denotes a draft. STAFF_CONFIRMED denotes a reviewed note. A draft promise leaves structured promise fields blank. A draft claim starts only a provisional reconciliation hold. |
| last_utterance | Synthetic borrower statement in their language, written as a transcript. Empty for no response or no prior interaction. Use for intent extraction or display. |

## Route, score and outcome labels

| Field | Meaning |
|---|---|
| expected_route | Operational action for the row as of the snapshot. Exact codes below. |
| priority_score | Integer only on CALL rows. A blank on every other route prevents a blocked account from entering the queue. Zero and negative values are valid eligible scores. |
| score_reason | Plain-English audit explanation for any scored or blocked row. |
| expected_rank | 1-based rank among all eligible borrowers across the five languages. |
| last_intent | Gold intent for the stored utterance. The eight speech classes also appear in voice/utterances.csv. NO_RESPONSE and NO_INTERACTION have no text. |
| paid_within_48h | 1 for any new verified positive payment, including a partial payment, within 48 hours after the cutoff. |
| new_verified_inr_48h | Sum of unique receipts both paid and verified in (cutoff, cutoff + 48h]. A pre-cutoff payment verified later can close a balance, but adds zero to this metric. |

Apply the first matching routing test in the following order. Payment, contact and promise gates run before any score.

| Condition | Route |
|---|---|
| Outstanding balance is zero | CLOSE_PAID |
| Stop-contact flag | SUPPRESS_OPT_OUT |
| Wrong number flag | SUPPRESS_WRONG_NUMBER |
| Open hardship | HUMAN_SUPPORT |
| Unverified payment claim | RECONCILE_CLAIM |
| Active promise due in future | WAIT_PROMISE |
| Promise due and latest balance check predates promise deadline | RECHECK_BALANCE |
| Requested callback outside the permitted window | REVIEW_CALLBACK_TIME |
| Requested callback still in future | WAIT_CALLBACK |
| Agreed partial-payment follow-up still in future | WAIT_AGREED_FOLLOWUP |
| Outside demo calling hours | WAIT_WINDOW |
| Previous outbound attempt less than 24 hours ago | COOLDOWN |
| Positive outstanding balance and all gates permit a call | CALL |

Score = 3 × callback due + min(2, prior payments after reminders) − min(2, prior unaided payments). A due callback is binary. Sort by descending score, then ascending borrower_id. Permitted scores range from −2 to 5. Language, name, area, raw transcripts, amount owed and the loan number have no score weight.

The synthetic contact policy uses [08:00, 19:00) India time, one outbound attempt per rolling 24 hours, and staff review for an out-of-window callback. At exactly 24 hours the cooldown has cleared. The sample books assume one borrower per contact and no extra approved calling window. These are configurable fixture assumptions.

## Ledgers, scripts, audio and replay

Both receipt tables use borrower_id, transaction_id, paid_at_ist, verified_at_ist, amount_inr and channel. amount_inr is a transaction delta. Deduplicate on transaction_id, even when deliveries have different event IDs. The cutoff ledger lists the already known receipts. The later ledger lists only newly verified transactions. SIMTX and SIMLINK identify local fixtures.

The voice manifest uses utterance_id, language_code, transcript and audio_path (relative to the voice/ folder). A blank audio_path denotes a text-only alternative. The answer key includes expected_intent, spoken_amount_inr, spoken_date_ist and spoken_time_ist. These slots contain the values explicitly given in amount offers, promises or callbacks. A relative reference like “yesterday” in a claim calls for reconciliation. It supplies no verified payment date. Role-play scripts cover the opening, identity check and next agent reply.

The five tags are en-IN (English), hi-IN (Hindi), kn-IN (Kannada), ta-IN (Tamil) and te-IN (Telugu). Every WAV is 8 kHz, mono, signed 16-bit PCM. Audio was synthesized with offline eSpeak 1.48.03. English uses the engine's general English voice and its Telugu voice is experimental. The locale identifies the intended service language. Audio is a clean functional fixture without human speakers or a native-speaker accent evaluation. Generate a Bulbul clip from the same transcript with tools/sarvam_voice.py if desired. API reference: https://docs.sarvam.ai/api-reference/text-to-speech/convert

The replay is synthetic application-level JSONL. Each delivery has a unique delivery_id, a stable event_id, a borrower ID, two timestamps, an event_type and a payload. Identical event IDs model transport retries. Different event IDs can also carry the same verified transaction. Order by delivered_at_ist, preserving the listed order for ties. Only the subset named in demo_index.csv appears in these illustrative streams. The later receipt ledger covers the entire book and is authoritative for evaluation. The PNG meeting notes are synthetic printed samples.

Fairness swaps change only name, service language and area on a copy of a snapshot. Keep borrower ID and all financial/contact fields fixed. Eligibility, score and explanation should match the original. Outcome differences across language groups can be examined separately. Row-level invariance alone does not establish population-level fairness.
