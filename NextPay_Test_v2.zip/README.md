# NextPay held-out test book v2

**Give the builder only blind/ and data_dictionary.md.** The facilitator keeps facilitator_only/ until a ranked submission is frozen. Folder separation is procedural. Anyone holding the complete ZIP can open the answer key.

The 18 November 2026 snapshot has **4,200 previously unseen borrower IDs**, 840 per language, matching the size of the problem statement's example. The book is sorted in its original loan-number order. It has new wording, a different mix of past payment behaviours, and combinations of conditions that were absent from training. There are no outcomes, expected routes, scores or ranks in blind/borrowers.csv.

## Run the blind round

1. Give the team blind/borrowers.csv and blind/receipts_at_snapshot.csv. Have them apply the agreed gates and priority score at the exact as_of_ist shown. Freeze their top-first list as a CSV with a borrower_id header. Use the same call budget for both strategies. The sponsor's example gives 360 calls per day.
2. For the separate voice task, present blind/voice/audio/ WAV files to the recogniser. Use the opaque filename stem as utterance_id. The manifest contains the transcripts for the separate intent-classification task. Keep the transcript column away from the recogniser when measuring speech recognition.
3. Apply blind/fairness_swaps.csv to copies of the original records. Test route, score and reasons. Optional OCR inputs are under blind/notes/.
4. After the list is frozen, run this command from the extracted test folder:

    python facilitator_only/tools/score_submission.py --book blind/borrowers.csv --key facilitator_only/answer_key.csv --submission my_queue.csv --k 360

For a shorter live walkthrough, both strategies can use the same smaller value of K. The baseline always uses original_order after filtering ineligible accounts. When the submitted queue contains blocked accounts they consume call slots, increasing ineligible_calls, and receive no recovery credit. The 48-hour metric can include partial payments.

## After opening the key

| File under facilitator_only/ | Purpose |
|---|---|
| answer_key.csv | Per-borrower correct route, score and reason, stable rank, intent and synthetic 48-hour outcomes |
| receipts_48h.csv | Verify the outcome labels from unique payment transactions |
| voice_answers.csv, call_scripts.csv | Score the 120 held-out texts and look up a localized agent response |
| replay/demo_index.csv | Find the six state-change scenarios in each language |
| replay/events.jsonl, replay/expected_after_delivery.csv | Replay events in delivered order and compare the result after each delivery |
| fairness_answers.csv, note_answers.csv | Check the swap results and reference field-note text |

The voice set includes 40 clean, synthetic offline WAVs, one per spoken intent per language. The test wording differs from training. Future receipts, demo account IDs and answer keys are reserved for the facilitator until the submissions have been saved. The later receipts are simulated observations. They cannot establish how much money was caused by a call or guarantee the proposed ordering beats the baseline.
