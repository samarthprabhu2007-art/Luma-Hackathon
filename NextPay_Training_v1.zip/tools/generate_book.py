"""Generate a synthetic NextPay snapshot and a private 48-hour evaluation key (stdlib only)."""
from __future__ import annotations
import argparse, csv, hashlib, json, random
from collections import defaultdict
from datetime import datetime, timedelta, timezone
from pathlib import Path
LANGS = ('en-IN', 'hi-IN', 'kn-IN', 'ta-IN', 'te-IN')
IST = timezone(timedelta(hours=5, minutes=30))
FULL = 'PAY_FULL'
PART = 'PAY_PARTIAL'
PROM = 'PROMISE_TO_PAY'
CLAIM = 'CLAIM_PAID'
CALLBACK = 'CALLBACK'
HARD = 'HARDSHIP'
WRONG = 'WRONG_NUMBER'
STOP = 'STOP_CONTACT'
DATES = {'v1': '2026-10-15T14:30:00+05:30'}
BASE_SCENARIOS = {'normal': 18, 'no_history': 4, 'partial_offer': 6, 'callback_due': 9, 'future_callback': 6, 'full_verified': 7, 'claim': 5, 'hardship': 5, 'wrong': 3, 'stop': 3, 'cooldown': 6, 'promise': 6, 'lapsed_unchecked': 4, 'lapsed_checked': 3, 'partial_plan': 4, 'expired': 4, 'cancelled': 3, 'no_answer': 3, 'note_claim': 2, 'note_promise': 2, 'confirmed_note_promise': 2}
ACTIONS = {'CLOSE_PAID': 'Verified receipts cover the current due. Remove from the call queue.', 'SUPPRESS_OPT_OUT': 'The contact asked to stop. Suppress automated calls and messages.', 'SUPPRESS_WRONG_NUMBER': 'The number belongs to a different person. Suppress it for this account.', 'HUMAN_SUPPORT': 'Hardship was reported. Stop automated contact and offer human support.', 'RECONCILE_CLAIM': 'A prior payment was claimed. Pause outreach and check the receipt.', 'WAIT_PROMISE': 'Wait for the promised payment date and check the balance then.', 'RECHECK_BALANCE': 'The promise lapsed. Verify the current balance before reconsidering outreach.', 'WAIT_CALLBACK': 'Wait until the borrower’s chosen callback time.', 'REVIEW_CALLBACK_TIME': 'The requested time is outside demo calling hours. Arrange a permitted time.', 'WAIT_AGREED_FOLLOWUP': 'Wait until the next follow-up agreed after a part payment.', 'WAIT_WINDOW': 'The demo calling window is closed.', 'COOLDOWN': 'An outbound call was attempted in the last 24 hours. Wait until the limit clears.'}

def stamp(t):
    return t.isoformat(timespec='seconds') if t else ''

def moment(s):
    return datetime.fromisoformat(s) if s else None

def export(path, rows, columns=None):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = columns or list(rows[0])
    with path.open('w', newline='', encoding='utf-8-sig') as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)

def read(path):
    with Path(path).open(newline='', encoding='utf-8-sig') as f:
        return list(csv.DictReader(f))

def write_jsonl(path, records):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(''.join((json.dumps(x, ensure_ascii=False) + '\n' for x in records)), encoding='utf-8')

def anon(rng, prefix):
    return f'{prefix}-{rng.getrandbits(64):016x}'

def hash_id(lang, words):
    return 'U-' + hashlib.sha256((lang + '|' + words).encode()).hexdigest()[:16]

def inside_window(t):
    return 8 <= t.astimezone(IST).hour < 19

def choose_route(row, at):
    if int(row['outstanding_inr']) == 0:
        return 'CLOSE_PAID'
    for field, action in [('stop_contact', 'SUPPRESS_OPT_OUT'), ('wrong_number', 'SUPPRESS_WRONG_NUMBER'), ('hardship_open', 'HUMAN_SUPPORT'), ('unverified_payment_claim', 'RECONCILE_CLAIM')]:
        if int(row[field]):
            return action
    due = moment(row['active_promise_due_ist'])
    if due:
        if due > at:
            return 'WAIT_PROMISE'
        if moment(row['balance_checked_at_ist']) < due:
            return 'RECHECK_BALANCE'
    cb = moment(row['requested_callback_at_ist'])
    if cb:
        if not inside_window(cb):
            return 'REVIEW_CALLBACK_TIME'
        if cb > at:
            return 'WAIT_CALLBACK'
    plan = moment(row['next_agreed_followup_ist'])
    if plan and plan > at:
        return 'WAIT_AGREED_FOLLOWUP'
    if not inside_window(at):
        return 'WAIT_WINDOW'
    recent = moment(row['last_outbound_attempt_ist'])
    if recent and at - recent < timedelta(hours=24):
        return 'COOLDOWN'
    return 'CALL'

def decide(row, at):
    route = choose_route(row, at)
    if route != 'CALL':
        return (route, None, ACTIONS[route])
    callback = moment(row['requested_callback_at_ist'])
    due = int(callback is not None and callback <= at)
    past = int(row['prior_payments_after_reminders'])
    solo = int(row['prior_unaided_payments'])
    score = 3 * due + min(2, past) - min(2, solo)
    reasons = ['Requested callback is due (+3).' if due else 'No callback is due (0).', f'{past} verified past payments followed reminders (+{min(2, past)}).', f'{solo} past payments were unaided (-{min(2, solo)}).']
    if row['active_promise_due_ist']:
        reasons.append('The promise date passed and the balance was checked.')
    if row['payment_link_status'] in ('EXPIRED', 'CANCELLED'):
        reasons.append('The old link is no longer active and a balance remains.')
    return (route, score, ' '.join(reasons))

def pick_templates(rows):
    bank = defaultdict(list)
    for row in rows:
        bank[row['language_code'], row['intent']].append(row['template'])
    return bank

def render(bank, lang, intent, amt, when, word_rng):
    if intent in ('NO_RESPONSE', 'NO_INTERACTION'):
        return ''
    return word_rng.choice(bank[lang, intent]).format(amount=amt, date=when.strftime('%d/%m/%Y'), time=when.strftime('%H:%M'))

def weight_choice(r, weights):
    return r.choices(list(weights), weights=list(weights.values()), k=1)[0]

def create(phrases, profile, per_language, seed, outcome_seed, as_of=None):
    if per_language < 45:
        raise ValueError('Use at least 45 rows per language so every case can be represented.')
    now = moment(as_of or DATES[profile])
    horizon = now + timedelta(hours=48)
    if now.utcoffset() != timedelta(hours=5, minutes=30) or not inside_window(now):
        raise ValueError('Use an IST snapshot inside the demo calling window.')
    rng = random.Random(seed)
    outcome_rng = random.Random(outcome_seed)
    rng_ids = random.Random(seed ^ 372097)
    words = random.Random(seed ^ 1598)
    loanrng = random.Random(seed ^ 44407)
    bank = pick_templates(phrases)
    rows = []
    obs = []
    key = []
    future = []
    anchors = {}
    hiddens = {}
    mix = BASE_SCENARIOS.copy()
    for lang in LANGS:
        required = ['demo_partial', 'demo_branch', 'demo_link', 'demo_lapse', 'demo_curfew', 'demo_full'] + list(mix)
        scenlist = required + [weight_choice(rng, mix) for _ in range(per_language - len(required))]
        rng.shuffle(scenlist)
        for scenario in scenlist:
            id = anon(rng_ids, 'B')
            gross = rng.choice([500, 650, 800, 950, 1000, 1200, 1450, 1750, 2000, 2250, 3000, 4500, 5800])
            profile_kind = weight_choice(rng, {'self': 31, 'reminded': 36, 'mixed': 20, 'slow': 13})
            probs = {'self': (0.1, 0.68), 'reminded': (0.58, 0.13), 'mixed': (0.3, 0.29), 'slow': (0.14, 0.1)}[profile_kind]
            cycles = 0 if scenario == 'no_history' else rng.randrange(1, 9)
            after = solo = 0
            for _ in range(cycles):
                v = rng.random()
                after += v < probs[0]
                solo += probs[0] <= v < sum(probs)
            received = 0
            status = 'ACTIVE'
            pending_cb = None
            promise = None
            promise_amount = None
            plan = None
            last_check = now - timedelta(minutes=rng.randrange(1, 90))
            last_out = now - timedelta(days=rng.randrange(2, 15), minutes=rng.randrange(0, 90)) if rng.random() < 0.72 else None
            spoken = now - timedelta(days=rng.randrange(3, 7), minutes=rng.randrange(0, 65))
            when = spoken
            intent = FULL
            offer = None
            claim = hard = wrong = stop = 0
            source = 'BORROWER_INBOUND'
            note_state = ''
            minimum = 100
            if scenario in ('normal', 'no_history', 'demo_branch', 'demo_curfew', 'demo_full'):
                if rng.random() < 0.4 or scenario in ('demo_branch', 'demo_curfew'):
                    intent = 'NO_INTERACTION'
                    source = 'NONE'
                    spoken = None
            if scenario in ('full_verified',):
                received = gross
                status = 'PAID'
            if scenario in ('claim', 'note_claim'):
                claim = 1
                intent = CLAIM
                if scenario == 'note_claim':
                    source = 'FIELD_NOTE'
                    note_state = 'AWAITING_STAFF_CONFIRMATION'
            if scenario in ('hardship', 'wrong', 'stop'):
                intent = {'hardship': HARD, 'wrong': WRONG}.get(scenario, STOP)
                hard = int(intent == HARD)
                wrong = int(intent == WRONG)
                stop = int(intent == STOP)
            if scenario in ('callback_due', 'future_callback'):
                intent = CALLBACK
                if scenario == 'callback_due':
                    pending_cb = now - timedelta(minutes=rng.choice([0, 5, 12, 20]))
                else:
                    pending_cb = (now + timedelta(days=rng.choice([1, 2, 3]))).replace(hour=rng.choice([9, 10, 15, 17]), minute=0)
                when = pending_cb
            if scenario in ('promise', 'note_promise', 'confirmed_note_promise', 'lapsed_checked', 'lapsed_unchecked', 'demo_lapse'):
                intent = PROM
                if scenario in ('promise', 'note_promise', 'confirmed_note_promise', 'demo_lapse'):
                    when = (now + timedelta(days=1 if scenario == 'demo_lapse' else rng.choice([1, 2, 3]))).replace(hour=23, minute=59, second=59)
                else:
                    when = (now - timedelta(days=1)).replace(hour=23, minute=59, second=59)
                offer = rng.choice([300, 500, min(gross, 800)])
                if scenario != 'note_promise':
                    promise = when
                    promise_amount = offer
                else:
                    source = 'FIELD_NOTE'
                    note_state = 'AWAITING_STAFF_CONFIRMATION'
                if scenario == 'confirmed_note_promise':
                    source = 'FIELD_NOTE'
                    note_state = 'STAFF_CONFIRMED'
                if scenario == 'lapsed_unchecked':
                    last_check = when - timedelta(hours=2)
            if scenario in ('partial_plan', 'partial_offer', 'demo_partial'):
                intent = PART
                offer = rng.choice([150, 200, 300, 400])
                if scenario == 'demo_partial':
                    gross = 1000
                    offer = 300
                if scenario == 'partial_plan':
                    received = offer
                    status = 'PARTIALLY_PAID'
                    plan = (now + timedelta(days=2)).replace(hour=12, minute=0)
            if scenario in ('expired', 'cancelled', 'demo_link'):
                status = 'CANCELLED' if scenario == 'cancelled' else 'EXPIRED'
            if scenario in ('cooldown', 'no_answer'):
                last_out = now - timedelta(hours=rng.choice([1, 2, 5, 23]))
                spoken = last_out
                source = 'OUTBOUND_CALL'
                if scenario == 'no_answer':
                    intent = 'NO_RESPONSE'
            if any((claim, hard, wrong, stop)) and last_out and spoken and (last_out > spoken):
                last_out = spoken - timedelta(days=1)
            row = dict(borrower_id=id, loan_number='', original_order=0, as_of_ist=stamp(now), language_code=lang, display_name='Demo ' + rng.choice(['Ari', 'Nila', 'Kiran', 'Tara', 'Dev', 'Manu', 'Ashu', 'Riya']), display_area='Demo Zone ' + rng.choice(list('ABCDEFGH')), opening_due_inr=gross, verified_received_inr=received, outstanding_inr=gross - received, history_cycles=cycles, prior_payments_after_reminders=after, prior_unaided_payments=solo, requested_callback_at_ist=stamp(pending_cb), active_promise_due_ist=stamp(promise), promised_inr=promise_amount if promise_amount is not None else '', next_agreed_followup_ist=stamp(plan), balance_checked_at_ist=stamp(last_check), last_outbound_attempt_ist=stamp(last_out), unverified_payment_claim=claim, hardship_open=hard, wrong_number=wrong, stop_contact=stop, payment_link_status=status, min_first_partial_inr=minimum, offered_partial_inr=offer if intent == PART else '', last_interaction_ist=stamp(spoken), interaction_source=source, note_review_state=note_state, last_utterance='')
            row['last_utterance'] = render(bank, lang, intent, offer or 0, when, words)
            if received:
                paid = now - timedelta(days=1, hours=2)
                obs.append(dict(borrower_id=id, transaction_id=anon(rng_ids, 'SIMTX'), paid_at_ist=stamp(paid), verified_at_ist=stamp(paid + timedelta(minutes=4)), amount_inr=received, channel='SIMULATED_PAYMENT_LINK'))
            if scenario.startswith('demo_'):
                anchors[lang, scenario] = id
            hiddens[id] = (scenario, intent, profile_kind)
            rows.append(row)
    loan_pool = range(1000000, 5500000)
    loan_numbers = loanrng.sample(loan_pool, len(rows))
    for row, loan in zip(rows, loan_numbers):
        row['loan_number'] = f'LN-{loan}'
    rows.sort(key=lambda r: r['loan_number'])
    for pos, row in enumerate(rows, 1):
        row['original_order'] = pos
        bid = row['borrower_id']
        sc, i, latent = hiddens[bid]
        balance = row['outstanding_inr']
        route, score, reason = decide(row, now)

        def add_receipt(t, amount, previous=False):
            if not 0 < amount <= balance:
                raise AssertionError(bid)
            confirmed = now + timedelta(minutes=30) if previous else t + timedelta(minutes=2)
            tx = dict(borrower_id=bid, transaction_id=anon(outcome_rng, 'SIMTX'), paid_at_ist=stamp(t), verified_at_ist=stamp(confirmed), amount_inr=amount, channel='SIMULATED_BRANCH_LEDGER' if previous else 'SIMULATED_PAYMENT_LINK')
            future.append(tx)
            return tx
        if sc == 'demo_partial':
            add_receipt(now + timedelta(minutes=10), 300)
            add_receipt(now + timedelta(hours=23), balance - 300)
        elif sc == 'demo_branch':
            add_receipt(now - timedelta(days=1), balance, True)
        elif sc == 'demo_full':
            add_receipt(now + timedelta(minutes=22), balance)
        elif sc in ('demo_curfew', 'demo_link', 'demo_lapse'):
            pass
        elif sc in ('claim', 'note_claim') and outcome_rng.random() < 0.55:
            add_receipt(moment(row['last_interaction_ist']) - timedelta(days=1), balance, True)
        elif balance > 0:
            p = {'self': 0.56, 'reminded': 0.53, 'mixed': 0.34, 'slow': 0.13}[latent]
            if route == 'HUMAN_SUPPORT':
                p *= 0.35
            if row['active_promise_due_ist'] and moment(row['active_promise_due_ist']) > horizon:
                p *= 0.5
            if outcome_rng.random() < p:
                amt = balance if outcome_rng.random() < 0.57 else min(balance, max(50, balance * outcome_rng.randint(15, 75) // 100 // 10 * 10))
                add_receipt(now + timedelta(minutes=outcome_rng.randint(5, 2860)), amt)
        key.append(dict(borrower_id=bid, expected_route=route, priority_score=score if score is not None else '', score_reason=reason, expected_rank='', last_intent=i, paid_within_48h=0, new_verified_inr_48h=0))
    key_by_id = {k['borrower_id']: k for k in key}
    rankable = sorted((k for k in key if k['expected_route'] == 'CALL'), key=lambda k: (-k['priority_score'], k['borrower_id']))
    for rank, k in enumerate(rankable, 1):
        k['expected_rank'] = rank
    for tx in future:
        if now < moment(tx['paid_at_ist']) <= moment(tx['verified_at_ist']) <= horizon:
            k = key_by_id[tx['borrower_id']]
            k['paid_within_48h'] = 1
            k['new_verified_inr_48h'] += tx['amount_inr']
    return (rows, key, obs, future, anchors)

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--phrases', type=Path, required=True, help='Labelled template CSV, e.g. tools/training_phrasebook.csv')
    p.add_argument('--out', type=Path, required=True)
    p.add_argument('--profile', choices=DATES, default='v1')
    p.add_argument('--per-language', type=int, default=1200)
    p.add_argument('--seed', type=int, required=True)
    p.add_argument('--outcome-seed', type=int, required=True)
    p.add_argument('--as-of', default=None)
    a = p.parse_args()
    if a.out.exists() and any(a.out.iterdir()):
        p.error('Choose an empty output directory.')
    b, k, observed, future, _ = create(read(a.phrases), a.profile, a.per_language, a.seed, a.outcome_seed, a.as_of)
    export(a.out / 'borrowers.csv', b)
    export(a.out / 'receipts_at_snapshot.csv', observed)
    export(a.out / 'evaluator_only/answer_key.csv', k)
    export(a.out / 'evaluator_only/later_receipts.csv', future)
if __name__ == '__main__':
    main()
