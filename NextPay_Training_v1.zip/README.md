# NextPay training book v1

Start with **borrowers.csv**. It contains 6,000 synthetic borrower accounts, with 1,200 each in English, Hindi, Kannada, Tamil and Telugu. The rule, explanations and 48-hour outcomes are labelled. Filter expected_route to CALL, then sort expected_rank ascending to see who would be called first. For an independent implementation, score using only snapshot columns. See data_dictionary.md for field definitions.

## What to open

| Question | File |
|---|---|
| Who is callable and why? | borrowers.csv |
| Which receipts were already known at the cutoff? | receipts_at_snapshot.csv |
| What did the borrower actually say in each language? | voice/utterances.csv |
| How should the agent open and reply? | practice/call_scripts.csv |
| What was paid and verified in the next 48 hours? | practice/receipts_48h.csv |
| Which accounts demonstrate each event? | practice/replay/demo_index.csv |
| How do I replay a partial payment or prior-payment claim? | practice/replay/events.jsonl and expected_after_delivery.csv in that folder |
| What happens if I change the name, area or service language? | fairness_swaps.csv |
| Which printed field notes need review? | notes/notes.csv and notes/images/ |

The speech set contains 120 labelled texts: three wordings for each of eight spoken intents in each of five languages. One wording per intent and language has a WAV, for 40 clips. NO_RESPONSE and NO_INTERACTION appear only in borrower records. Voice/utterance IDs are join keys. Source files are lowercase on disk.

## Two demos to try first

1. Play **voice/audio/U-21f2cff9a06e9512.wav**. The Kannada borrower says **ನಾನು ನಿನ್ನೆ ಬ್ಯಾಂಕ್‌ನಲ್ಲಿ ಹಣ ಕಟ್ಟಿದ್ದೇನೆ.** (“I deposited the money at the bank yesterday”). In practice/replay/demo_index.csv, select kn-IN + demo_branch. Apply its BORROWER_UTTERANCE delivery, observe RECONCILE_CLAIM and the unchanged balance, then apply its verified branch receipt and observe CLOSE_PAID. That older deposit adds ₹0 to the new-recovery metric.
2. Pick demo_partial for any language. A verified ₹300 arrives against ₹1,000. The balance becomes ₹700. Retry the exact delivery. It stays ₹700. After the next verified ₹700 the balance is zero. A second delivery of the original transaction cannot reopen the account.

## Borrower generator and Bulbul option

Python 3.9+ is sufficient for the supplied command-line tools. The generator creates fresh tabular snapshots. It takes labelled phrase templates and separate random seeds for borrowers and outcomes. To recreate the training tables in a new folder:

    python tools/generate_book.py --phrases tools/training_phrasebook.csv --profile v1 --per-language 1200 --seed 718130 --outcome-seed 903176 --out new_book

The generator writes inputs and labels separately. Join evaluator_only/answer_key.csv to borrowers.csv by borrower_id to obtain the combined training layout. To generate a different practice book, change both seeds. The supplied training phrasebook contains only training wordings. The default date is 15 October 2026, 14:30 IST.

With your own SARVAM_API_KEY set, this optional command sends just this synthetic line to Bulbul and writes a new WAV:

    python tools/sarvam_voice.py --manifest voice/utterances.csv --utterance-id U-21f2cff9a06e9512 --out kannada_bulbul.wav

The packaged clips use offline eSpeak and were not created with Sarvam. The optional helper follows the documented Bulbul v3 REST API and needs network access and an authorised key.

## Evaluate a queue

Save a CSV with header borrower_id and one ID per line, first call first. From this folder run:

    python tools/score_submission.py --book borrowers.csv --key borrowers.csv --submission my_queue.csv --k 360

The scorer reports confirmed payers/K, verified rupees and ineligible calls. It compares the submission with the first K eligible borrowers in original loan order. The records and receipts are synthetic. A higher score on this book measures prediction on this simulation. Establishing whether outreach caused payment would require a different evaluation design.
